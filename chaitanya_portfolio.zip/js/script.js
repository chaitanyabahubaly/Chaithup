
document.addEventListener('DOMContentLoaded', function() {
    alert('Welcome to Chaitanya Rao's Portfolio!');
});
